#!/bin/bash

./lgtm_facial_recognition haarcascades/haarcascade_frontalface_default.xml "$@"
