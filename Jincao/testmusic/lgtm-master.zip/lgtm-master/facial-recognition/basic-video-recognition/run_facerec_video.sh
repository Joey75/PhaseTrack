#!/bin/bash

./facerec_video haarcascades/haarcascade_frontalface_default.xml yalefaces.csv 1
