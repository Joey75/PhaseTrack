#ifndef __IWL_CONNECTOR_H__
#define __IWL_CONNECTOR_H__

#include <linux/connector.h>
#include "connector_users.h"

#define CN_IDX_IWLAGN   (CN_NETLINK_USERS + 0xf)
#define CN_VAL_IWLAGN   0x1

#endif /* __IWL_CONNECTOR_H__ */
