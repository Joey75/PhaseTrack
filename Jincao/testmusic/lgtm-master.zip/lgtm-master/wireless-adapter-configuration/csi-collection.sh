#!/usr/bin/sudo /bin/sh

../../linux-80211n-csitool-supplementary/netlink/log_to_file $1
